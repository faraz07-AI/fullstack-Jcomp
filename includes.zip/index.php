

<?php
  require "header.php";
?>

   <main>
        <link rel="stylesheet" href="ind.css">
        <?php
          if(isset($_SESSION['uid'])){
           echo '<p><h1><center>you are logged in!</center></h1></p>';
          }         
      else{
        echo '<p>you are logged out!!!</p>';
         }
       ?>
    </main>
