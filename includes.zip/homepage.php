

<html>
<head>
<title>my web application</title>
</head>
<frameset rows="30%,60%">
<frame src="3.html" name=f3>
<frameset cols="40%,60%">
<frame src="1.html" name=f1>
<frame src="2.html" name=f2>
</frameset>
</frameset>
</html>